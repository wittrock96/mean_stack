let express = require('express'),
	app=express(),
	bodyParser=require('body-parser'),
	mongoose=require('mongoose');

var Schema = mongoose.Schema;

app.use(bodyParser.json())
app.use(express.static( __dirname + '/beltapp/dist' ));

let ProductSchema = new mongoose.Schema({
	name: { type: String, minlength: 3, required: [true, 'please enter name']},
	qty: {type: Number, required: [true, 'this needs a quantity']},
	price: {type: Number, required: [true, 'please enter a price']}

}, {timestamps: true})




mongoose.connect('mongodb://localhost/products')
mongoose.Promise = global.Promise;

mongoose.model('Product', ProductSchema)


var Product = mongoose.model('Product')

app.get('/products', (req, res)=>{
	Product.find({}, (err, products)=>{
		if(err){
			console.log('error in finding all')
			res.json({message:'error', error: err})
		}
		else{
			console.log(products)
			res.json({message: 'success', products: products})
		}
	})
})
app.get('/product/:id', (req, res)=>{
	console.log('inside server')
	Product.findOne({_id: req.params.id}, (err, product)=>{
		if(err){
			console.log('error in finding one')	
			res.json({message:'error', error: err})
		}
		else{
			
			console.log('got the product, coming back', product)
			res.json({message: 'success', product: product})
		}

	})
})
app.post('/product/new', (req, res)=>{
	console.log('inside server')
	let product = new Product({name: req.body.name, qty: req.body.qty, price: req.body.price})
	product.save((err)=>{
		console.log('creating product')
		if(err){
			console.log('something went wrong inside err')
			res.json({message: 'error', error: err})
		}
		else{
			console.log('created product')
			res.json('added product')
		}
	})
})
app.patch('/product/edit/:id', (req, res)=>{
	console.log('inside app.patch')
		Product.findOne({_id:req.params.id}, (err, product)=>{
			if (err){
				console.log('soemthing wrong in 1', err)
				res.status(400).json({message:'error', error: err})
			}
			else{
				product.name = req.body.name;
				product.qty = req.body.qty;
				product.price = req.body.price;
				product.save((err)=>{
					if(err){
						console.log('soemthing wrong in 2')
						res.status(400).json({message:'error', error: err})
					}
					else{
						console.log('holy shit it worked')
						res.json({message: 'success', product: product})

					}
				})
				
			}
		})

		// Product.findByIdAndUpdate({_id: req.params.id, name: req.body.name, qty: req.body.qty, price: req.body.price},(err, product)=>{
		// 	if(err){
		// 		console.log('something went wront', err)
		// 		res.json({message: 'error', error: err})

		// 	}
		// 	else{
		// 		console.log('holy shit it worked')
		// 		res.json({message:'success', product:product})
		// 	}
		// })
})
app.delete('/delete/:id', (req, res)=>{
	console.log('inside delete')
	let product = Product.findOneAndRemove({_id: req.params.id},(err, product)=>{
		console.log('product deleted')
		res.json({message: 'success'})
	})
})

app.listen(8000, function(){
	console.log('listening on port 8000')
})