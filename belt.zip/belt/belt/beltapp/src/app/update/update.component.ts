import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router'

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
	current_product: any;
	product: any;
  constructor(
  	private _httpService: HttpService,
  	private _route: ActivatedRoute,
  	private _router: Router) { }

  ngOnInit() {
  	this.product = {name: '', qty: '', price: ''}
  	console.log('intializing')
  	this._route.params.subscribe((params: Params)=>{
  		console.log('setting id to get product', params['id'])
  		this.oneProduct(params['id'])

  	})

  }
  oneProduct(id){
  	console.log('getting product', id)
  	let observable = this._httpService.getProduct(id)
  	observable.subscribe(data =>{
  		data = data.json()
  		console.log('got the product', data)

  		this.current_product = data
  		console.log(this.current_product.product.name)
  	})
  }
  updateProduct(event){
  	event.preventDefault()
  	console.log('update form submitted')
  	let observable = this._httpService.edit(this.product)
  	observable.subscribe(data =>{
  		data = data.json()
  		console.log('updated')
  		this.current_product = data
  		this.product = {name: '', qty: '', price: ''}
  	})
  }
}
