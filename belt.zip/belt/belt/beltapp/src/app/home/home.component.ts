import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
	products = [];
  constructor(
  	private _httpService: HttpService,
  	private _route: ActivatedRoute,
  	private _router: Router) { }

  ngOnInit() {
  	this.allInfo()
  }
  allInfo(){
  	console.log('inside client request')
  	let observable = this._httpService.allProducts()
  	observable.subscribe(data=>{
  		data = data.json()
  		this.products = data['products']
  		console.log(data)
  		console.log(this.products)
  	})
  }

}
