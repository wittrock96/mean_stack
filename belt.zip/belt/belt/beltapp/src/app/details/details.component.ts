import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router'

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
	product: any;
	product_id:any;
  constructor(
  	private _httpService: HttpService,
  	private _route: ActivatedRoute,
  	private _router: Router) { }

  ngOnInit() {
  	console.log('intializing')
  	this._route.params.subscribe((params: Params)=>{
  		console.log('setting id to get product', params['id'])
  		this.oneProduct(params['id'])

  	})

  }
  oneProduct(id){
  	console.log('getting product', id)
  	let observable = this._httpService.getProduct(id)
  	observable.subscribe(data =>{
  		data = data.json()
  		console.log('got the product', data)

  		this.product = data
  		console.log(this.product.product.name)
  	})
  }
  destroyProduct(){
  	console.log('detroying')
  	let observable = this._httpService.destroy(this.product.product._id)
  	observable.subscribe(data =>{
  			console.log('deleted', data)
  		})
  }

}
