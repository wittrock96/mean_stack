import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { ActivatedRoute, Params, Router} from '@angular/router'

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
	brandNew: any;
	response: any;
  constructor(
  	private _httpService: HttpService,
  	private _route: ActivatedRoute,
  	private _router: Router) { }

  ngOnInit() {
  	this.brandNew = {name: '', qty: '', price: ''}
  }
  createProduct(event){
  	event.preventDefault()


  	let observable = this._httpService.newProduct(this.brandNew)
  	observable.subscribe(data =>{
  		this.response = data.json()
  		this.brandNew = {name: '', qty: '', price: ''}
  	})
  }

}
