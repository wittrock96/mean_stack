import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
@Injectable()
export class HttpService {

  constructor(private _http: Http) { }
  allProducts(){
  	return this._http.get('/products')
  }
  newProduct(brandNew){
  	return this._http.post('/product/new', brandNew)
  }
  getProduct(id){
  	console.log('inside service, going to server', id)
  	return this._http.get(`/product/${id}`, id)
  }
  edit(product){
  	console.log('inside editProduct, going to server', product)
  	return this._http.patch(`/product/edit/${product._id}`, product)
  }
  destroy(id){
  	console.log('inside HttpService')
  	return this._http.delete(`/delete/${id}`)
  }
}
